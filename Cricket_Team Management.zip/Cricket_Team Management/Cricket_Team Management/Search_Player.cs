﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Cricket_Team_Management
{
    public partial class Search_Player : Form
    {
        SqlConnection conn;
        public Search_Player()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            paneldetails.Visible = false;
            string id = txtpid.Text;
            string qurey = "Select * from players where player_id = " + id;
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(qurey, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    Players_Details p = new Players_Details();
                    p.Playerid = int.Parse(reader[0].ToString());
                    p.Playername = reader[1].ToString();
                    p.Playerage = int.Parse(reader[2].ToString());
                    p.Playerrole = reader[3].ToString();
                    p.Teamid = Convert.ToInt32(reader[4].ToString());
                    lblid.Text = p.Playerid.ToString();
                    lblname.Text = p.Playername;
                    lblage.Text = p.Playerage.ToString();
                    lblrole.Text = p.Playerrole;
                    lblteamid.Text = p.Teamid.ToString();
                    paneldetails.Visible = true;
                }
                else
                    MessageBox.Show("Player id doesnot exist");
                conn.Close();
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
            
        }

        private void Search_Player_Load(object sender, EventArgs e)
        {
            paneldetails.Visible = false;
        }
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            Players ob = new Players();
            ob.Show();
            base.OnFormClosed(e);
        }
    }
}
