﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Cricket_Team_Management
{
    public partial class Display_Players : Form
    {
        SqlConnection conn;
        public Display_Players()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void Dispaly_Players_Load(object sender, EventArgs e)
        {
            string query = "select * from players";
            //List<Country_Details> c = new List<Country_Details>();

            //MessageBox.Show(query);
            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataSet ds = new DataSet("mydetails");
                da.Fill(ds);
                dgdisplay.DataSource = ds.Tables[0];
                //MessageBox.Show("Displayed records successfully");
                conn.Close();
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            Players ob = new Players();
            ob.Show();
            base.OnFormClosed(e);
        }
    }
}
