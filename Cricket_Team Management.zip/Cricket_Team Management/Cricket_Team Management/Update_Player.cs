﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Cricket_Team_Management
{
    public partial class Update_Player : Form
    {
        SqlConnection conn;
        public Update_Player()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void Update_Player_Load(object sender, EventArgs e)
        {
            paneldetails.Visible = false;
        }

        private void btnsearch_Click(object sender, EventArgs e)
        {
            paneldetails.Visible = false;
            string id = txtpid.Text;
            string qurey = "Select * from players where player_id = " + id;
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(qurey, conn);
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    Players_Details p = new Players_Details();
                    p.Playerid = int.Parse(reader[0].ToString());
                    p.Playername = reader[1].ToString();
                    p.Playerage = int.Parse(reader[2].ToString());
                    p.Playerrole = reader[3].ToString();
                    p.Teamid = Convert.ToInt32(reader[4].ToString());
                    updateme(p);
                }
                else
                    MessageBox.Show("Player id doesnot exist");
                conn.Close();
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
               
            }
           
        }
        private void updateme(Players_Details p)
        {
            txtpname.Text = p.Playername;
            txtpage.Text = p.Playerage.ToString();
            txtprole.Text = p.Playerrole;
            txtteamid.Text = p.Teamid.ToString();
            paneldetails.Visible = true;
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            string query;
            query = string.Format("update players set  player_name = '{0}', player_age = '{1}', player_role = '{2}', team_id = '{3}' where player_id = '{4}'", txtpname.Text, txtpage.Text, txtprole.Text, txtteamid.Text, txtpid.Text);

            MessageBox.Show(query);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Updated Success");
                conn.Close();
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            Players ob = new Players();
            ob.Show();
            base.OnFormClosed(e);
        }
    }
}
