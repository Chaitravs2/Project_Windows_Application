﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Cricket_Team_Management
{
    public partial class Update_Match : Form
    {
        SqlConnection conn;
        public Update_Match()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            Matches ob = new Matches();
            ob.Show();
            base.OnFormClosed(e);
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            panel.Visible = false;
            string id = txttid.Value.ToString();
            try
            {
                conn.Open();
                string query = "select * from matches where match_id=" + id;
                SqlCommand cmd = new SqlCommand(query, conn);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {

                    Match_Details m = new Match_Details();
                    m.match_id = int.Parse(reader[0].ToString());
                    m.team1 = reader[1].ToString();
                    m.team2 = reader[2].ToString();
                    m.date_of_match = reader[3].ToString();
                    m.stadium_name = reader[4].ToString();
                    updateme(m);
                    panel.Visible = true;
                }
                else
                    MessageBox.Show(" sorry match id does not exist");
                conn.Close();
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }

        private void btnsubmit_Click(object sender, EventArgs e)
        {
            string query = string.Format("update matches set team_1='{0}',team_2='{1}', date_of_match='{2}', stadium_name='{3}' where match_id = {4}", txtt1.Text, txtt2.Text, dtmatch.Text, txtstadium.Text,txttid.Value);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Record Updated");
                conn.Close();

            }
            catch (Exception ob)
            {
                MessageBox.Show("Data cannot be updated \n" + ob.Message);
            }
        }

        private void updateme(Match_Details t)
        {

            txtt1.Text = t.team1;
            txtt2.Text = t.team2;
            dtmatch.Text = t.date_of_match;
            txtstadium.Text = t.stadium_name;
            panel.Visible = true;
        }

        private void Update_Match_Load(object sender, EventArgs e)
        {
            panel.Visible = false;
        }
    }
}
