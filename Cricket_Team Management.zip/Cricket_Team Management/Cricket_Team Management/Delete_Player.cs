﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Cricket_Team_Management
{
    public partial class Delete_Player : Form
    {
        SqlConnection conn;
        public Delete_Player()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void Delete_Player_Load(object sender, EventArgs e)
        {
            string query = "select * from teams";
            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataSet ds = new DataSet();
                da.Fill(ds);
                cmbteamid.DataSource = ds.Tables[0];
                cmbteamid.ValueMember = ds.Tables[0].Columns[0].ToString();
                cmbteamid.DisplayMember = ds.Tables[0].Columns[0].ToString();
                conn.Close();

            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }

        private void btnplayername_Click(object sender, EventArgs e)
        {
            string query = string.Format("select * from players w" +
                "here team_id = {0}", cmbteamid.Text);
            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataSet ds = new DataSet();
                da.Fill(ds);
                cmbpplayername.DataSource = ds.Tables[0];
                cmbpplayername.ValueMember = ds.Tables[0].Columns[1].ToString();
                cmbpplayername.DisplayMember = ds.Tables[0].Columns[1].ToString();
                conn.Close();

            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            string query = string.Format("delete from players where player_name='{0}'", cmbpplayername.Text);
            MessageBox.Show(query);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted record successfully");
                conn.Close();
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            Players ob = new Players();
            ob.Show();
            base.OnFormClosed(e);
        }
    }
}
