﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Cricket_Team_Management
{
    public partial class Display_team : Form
    {
        SqlConnection conn;
        public Display_team()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            Teams ob = new Teams();
            ob.Show();
            base.OnFormClosed(e);
        }

        private void dgdisplay_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Display_team_Load(object sender, EventArgs e)
        {
            string query = "select * from teams";
            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataSet ds = new DataSet("mydetails");
                da.Fill(ds);
                dgdisplay.DataSource = ds.Tables[0];
                //MessageBox.Show("Displayed records successfully");
                conn.Close();
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }
    }
}
