﻿namespace Cricket_Team_Management
{
    partial class Add_Team
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbcid = new System.Windows.Forms.ComboBox();
            this.btnsubmit = new System.Windows.Forms.Button();
            this.txttname = new System.Windows.Forms.TextBox();
            this.txttid = new System.Windows.Forms.NumericUpDown();
            this.lblcid = new System.Windows.Forms.Label();
            this.lblname = new System.Windows.Forms.Label();
            this.lblid = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.txttid)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbcid
            // 
            this.cmbcid.FormattingEnabled = true;
            this.cmbcid.Location = new System.Drawing.Point(248, 134);
            this.cmbcid.Margin = new System.Windows.Forms.Padding(2);
            this.cmbcid.Name = "cmbcid";
            this.cmbcid.Size = new System.Drawing.Size(247, 21);
            this.cmbcid.TabIndex = 14;
            // 
            // btnsubmit
            // 
            this.btnsubmit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnsubmit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnsubmit.Location = new System.Drawing.Point(248, 206);
            this.btnsubmit.Margin = new System.Windows.Forms.Padding(2);
            this.btnsubmit.Name = "btnsubmit";
            this.btnsubmit.Size = new System.Drawing.Size(95, 35);
            this.btnsubmit.TabIndex = 13;
            this.btnsubmit.Text = "SUBMIT";
            this.btnsubmit.UseVisualStyleBackColor = false;
            this.btnsubmit.Click += new System.EventHandler(this.btnsubmit_Click);
            // 
            // txttname
            // 
            this.txttname.Location = new System.Drawing.Point(248, 90);
            this.txttname.Margin = new System.Windows.Forms.Padding(2);
            this.txttname.Name = "txttname";
            this.txttname.Size = new System.Drawing.Size(247, 20);
            this.txttname.TabIndex = 12;
            // 
            // txttid
            // 
            this.txttid.Location = new System.Drawing.Point(248, 42);
            this.txttid.Margin = new System.Windows.Forms.Padding(2);
            this.txttid.Name = "txttid";
            this.txttid.Size = new System.Drawing.Size(247, 20);
            this.txttid.TabIndex = 11;
            // 
            // lblcid
            // 
            this.lblcid.AutoSize = true;
            this.lblcid.BackColor = System.Drawing.Color.Black;
            this.lblcid.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcid.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lblcid.Location = new System.Drawing.Point(71, 134);
            this.lblcid.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblcid.Name = "lblcid";
            this.lblcid.Size = new System.Drawing.Size(100, 18);
            this.lblcid.TabIndex = 10;
            this.lblcid.Text = "COUNTRY ID";
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.BackColor = System.Drawing.Color.Black;
            this.lblname.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lblname.Location = new System.Drawing.Point(71, 90);
            this.lblname.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(96, 18);
            this.lblname.TabIndex = 9;
            this.lblname.Text = "TEAM NAME";
            // 
            // lblid
            // 
            this.lblid.AutoSize = true;
            this.lblid.BackColor = System.Drawing.Color.Black;
            this.lblid.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblid.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.lblid.Location = new System.Drawing.Point(71, 49);
            this.lblid.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblid.Name = "lblid";
            this.lblid.Size = new System.Drawing.Size(67, 18);
            this.lblid.TabIndex = 8;
            this.lblid.Text = "TEAM ID";
            this.lblid.Click += new System.EventHandler(this.lblid_Click);
            // 
            // Add_Team
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.cmbcid);
            this.Controls.Add(this.btnsubmit);
            this.Controls.Add(this.txttname);
            this.Controls.Add(this.txttid);
            this.Controls.Add(this.lblcid);
            this.Controls.Add(this.lblname);
            this.Controls.Add(this.lblid);
            this.Name = "Add_Team";
            this.Text = "Add_Team";
            this.Load += new System.EventHandler(this.Add_Team_Load);
            ((System.ComponentModel.ISupportInitialize)(this.txttid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbcid;
        private System.Windows.Forms.Button btnsubmit;
        private System.Windows.Forms.TextBox txttname;
        private System.Windows.Forms.NumericUpDown txttid;
        private System.Windows.Forms.Label lblcid;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lblid;
    }
}