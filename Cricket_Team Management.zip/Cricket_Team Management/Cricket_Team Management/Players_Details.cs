﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cricket_Team_Management
{
    class Players_Details
    {
        public int Playerid { get; set; }
        public string Playername { get; set; }
        public int Playerage { get; set; }
        public string Playerrole { get; set; }
        public int Teamid { get; set; }
    }
}
