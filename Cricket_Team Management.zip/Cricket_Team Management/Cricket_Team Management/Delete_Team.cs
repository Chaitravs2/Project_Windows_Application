﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Cricket_Team_Management
{
    public partial class Delete_Team : Form
    {
        SqlConnection conn;
        public Delete_Team()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            Teams ob = new Teams();
            ob.Show();
            base.OnFormClosed(e);
        }
        private void Delete_Team_Load(object sender, EventArgs e)
        {
            string query = "select * from teams";
            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataSet ds = new DataSet();
                da.Fill(ds);
                cmbdel.DataSource = ds.Tables[0];
                cmbdel.ValueMember = ds.Tables[0].Columns[0].ToString();
                cmbdel.DisplayMember = ds.Tables[0].Columns[1].ToString();
                conn.Close();

            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            string query = string.Format("delete from teams where team_name='{0}'", cmbdel.Text);
            MessageBox.Show(query);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted record successfully");
                conn.Close();
            }
            catch (Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }
    }
}
