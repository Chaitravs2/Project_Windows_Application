﻿using System;
using System.Data.SqlClient;
using System.Configuration;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cricket_Team_Management
{
    public partial class Delete_Country : Form
    {
        SqlConnection conn;
        public Delete_Country()
        {
            InitializeComponent();
            conn = new SqlConnection(ConfigurationManager.ConnectionStrings["mydb"].ConnectionString);
        }

        private void Delete_Country_Load(object sender, EventArgs e)
        {
            string query = "select * from countries";
            try
            {
                conn.Open();
                SqlDataAdapter da = new SqlDataAdapter(query, conn);
                DataSet ds = new DataSet();
                da.Fill(ds);
                cmbcname.DataSource = ds.Tables[0];
                cmbcname.ValueMember = ds.Tables[0].Columns[0].ToString();
                cmbcname.DisplayMember = ds.Tables[0].Columns[1].ToString();
                conn.Close();

            }
            catch(Exception ob)
            {
                MessageBox.Show(ob.Message);
            }


        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            string query = string.Format("delete from countries where country_name='{0}'",cmbcname.Text);
            MessageBox.Show(query);
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Deleted record successfully");
                conn.Close();
            }
            catch(Exception ob)
            {
                MessageBox.Show(ob.Message);
            }
        }
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            Countries ob = new Countries();
            ob.Show();
            base.OnFormClosed(e);
        }
    }
}
